This is a partial copy of Boost 1.60, specifically only the parts that
boost/lockfree/queue.hpp depends on (extracted using bcp).